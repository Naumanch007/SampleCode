<?php $__env->startSection('content'); ?>
    <studio-component :coaching-options="<?php echo e(json_encode($coachingOptions, true)); ?>"
                      :city-options="<?php echo e(json_encode($cityOptions, true)); ?>"></studio-component>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /Applications/XAMPP/xamppfiles/htdocs/check24/resources/views/search.blade.php ENDPATH**/ ?>